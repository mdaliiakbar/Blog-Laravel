
<?php $__env->startSection('title','New Password'); ?>

<?php $__env->startSection("script"); ?>
    <script src="assets/libs/parsleyjs/parsley.min.js"></script>

    <!-- validation init -->
    <script src="assets/js/pages/form-validation.init.js"></script>
    <script>
        var id;
        $(document).ready(function(){


        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">

        <!-- Start Content-->
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Account Settings</a></li>
                                <li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
                            </ol>
                        </div>
                        <h4 class="page-title"><?php echo $__env->yieldContent('title'); ?></h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->


            <div class="row saveForm" >
                <div class="col-lg-12">

                    <div class="card-box">
                        <?php if($errors->any()): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="alert alert-danger"><?php echo e($error); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                        <form method="post" class="parsley-examples" action="<?php echo e(route("change-password")); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row">

                                <div class="col-md-4">
                                    <label for="current-password">Current Password <span class="text-danger">*</span></label>
                                    <input type="password"  name="current-password" class="form-control" id="current-password" required>
                                    <?php if($errors->has('current-password')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('current-password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="new-password">New Password <span class="text-danger">*</span></label>
                                    <input type="password"  name="new-password" class="form-control" id="new-password" required>
                                    <?php if($errors->has('current-password')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('current-password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="new-password_confirmation">Confirm Password <span class="text-danger">*</span></label>
                                    <input type="password"  name="new-password_confirmation" class="form-control" id="new-password_confirmation" required>

                                </div>
                            </div>


                            <div class="row">
                                <div class="col-md-12 text-center" style="margin-top: 20px;">
                                    <button value="1" class="btn btn-primary waves-effect waves-light mr-1" name="save" type="submit">
                                        <i class="fa fa-save"></i>  Save
                                    </button>
                                </div>
                            </div>

                        </form>
                    </div> <!-- end card-box -->
                </div>
                <!-- end col -->

            </div>
            <!-- end row -->


        </div> <!-- container-fluid -->

    </div> <!-- content -->

    <style>
        input::-webkit-outer-spin-button,
        input::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }
        input[type=number]{
            -moz-appearance: textfield;
        }
        input,select,textarea{
            margin-bottom: 8px;
        }
    </style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\akbar\laravel\blog\resources\views/auth/newpassword.blade.php ENDPATH**/ ?>