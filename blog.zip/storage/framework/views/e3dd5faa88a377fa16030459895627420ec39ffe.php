
<?php $__env->startSection('title','Trash'); ?>
<?php $__env->startSection("style"); ?>
<link href="<?php echo e(asset('assets/libs/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/libs/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection("script"); ?>
<script src="<?php echo e(asset('assets/libs/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

<script>
	
	$(document).ready(function(){

	});

	function confirmation(text){
		if(confirm(text)){
			return true;
		} return false;
	}
</script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


	<div class="content">

		<!-- Start Content-->
		<div class="container-fluid">

			<!-- start page title -->
			<div class="row">
				<div class="col-12">
					<div class="page-title-box">
						<div class="page-title-right">
							<ol class="breadcrumb m-0">
								<li class="breadcrumb-item"><a href="javascript: void(0);">Trash</a></li>
								<li class="breadcrumb-item active">Blog Manger</li>
							</ol>
						</div>
						<h4 class="page-title"><?php echo $__env->yieldContent("title"); ?></h4>
					</div>
				</div>
			</div>
			<!-- end page title -->

			<div class="row">
				<div class="col-12">
					<?php if(session()->has('msg')): ?>
					<div class="card-box">						
						<div class="alert alert-success">
							<?php echo e(session()->get('msg')); ?>

						</div>						
					</div> <!-- end card-box -->
					<?php endif; ?>
					<div class="card-box">
						<table id="studentList" class="table table-bordered dt-responsive nowrap">
							<thead>
							<tr>
								<th style="width: 5%" class="text-center">#</th>
								<th style="width: 50%">Title</th>
								<th style="width: 15%" class="text-center">Post At</th>
								<th style="width: 15%" class="text-center">Delete At</th>
								<th style="width: 10%" class="text-center">Action</th>
							</tr>
							</thead>
							<tbody>
								<?php if(count($news)>0): ?>
								<?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td class="text-center"><?php echo e($key+1); ?> </td>
									<td>
										<div class="badge badge-primary"><?php echo e($item->category->title); ?></div>
										<?php echo e($item->title); ?> 
									</td>
									<td class="text-center"><?php echo e($item->news_date); ?> </td>
									<td class="text-center"><?php echo e($item->deleted_at); ?> </td>
									<td class="text-center"> 
										<form style="display:inline;" action="<?php echo e(route("news-del-forever")); ?>" method="post" onsubmit="return confirmation('Are you sure to delete forever?')">
											<?php echo e(csrf_field()); ?>

											<input type="hidden" name="id" value="<?php echo e($item->id); ?>">
											<div class="btn-group">
												<a title="Restore" data-toggle="tooltip" data-placement="top" href="<?php echo e(route("news-restore",$item->id)); ?>" class="fa fa-retweet btn btn-sm btn-primary"  onclick="return confirmation('Are you sure to restore?')"></a> 
												<button title="Delete Forever" data-toggle="tooltip" data-placement="top" type="submit" class="fa fa-trash btn btn-sm btn-danger"></button> 
											</div>
										</form>
									</td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php else: ?>
								<tr>
									<td class="text-center" colspan="5">No data found!</td>
								</tr>
								<?php endif; ?>
								
							</tbody>
						</table>
					</div> <!-- end card-box -->
				</div> <!-- end col -->
			</div> <!-- end row -->


		</div> <!-- container-fluid -->

	</div> <!-- content -->


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\akbar\laravel\blog\resources\views/app/news/trash.blade.php ENDPATH**/ ?>