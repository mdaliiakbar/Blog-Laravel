<!DOCTYPE html>
<html lang="en">
	
	<head>
		<meta charset="utf-8" />
		<title><?php echo $__env->yieldContent("title"); ?> :: <?php echo e(config('constants.software.name')); ?></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta content="" name="description" />
		<meta content="" name="author" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<!-- App favicon -->
		<link rel="shortcut icon" href="<?php echo e(asset('assets/images/logo-sm.png')); ?>">
		
		<!-- jvectormap -->
		<link href="<?php echo e(asset("assets/libs/jqvmap/jqvmap.min.css")); ?>" rel="stylesheet" />
		
		<?php echo $__env->yieldContent("style"); ?>
		
		<link href="<?php echo e(asset("assets/libs/select2/select2.min.css")); ?>" rel="stylesheet" type="text/css" />
		<!-- App css -->
		<link href="<?php echo e(asset("assets/css/bootstrap.min.css")); ?>" rel="stylesheet" type="text/css" />
		<link href="<?php echo e(asset("assets/css/icons.min.css")); ?>" rel="stylesheet" type="text/css" />
		<link href="<?php echo e(asset("assets/css/app.min.css")); ?>" rel="stylesheet" type="text/css" />
		
	</head>
	
	<body>
		
		<!-- Begin page -->
		<div id="wrapper">
			<?php echo $__env->make("layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php echo $__env->make("layouts.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<div class="content-page">
				<?php echo $__env->yieldContent("content"); ?>  <!-- Footer Start -->
				<footer class="footer">
					<div class="container-fluid">
						<div class="row">
							<div class="col-md-12 text-center">
								<?php echo e(config('constants.development.session')); ?> &copy; <?php echo e(config('constants.software.name')); ?> Developed by <a href="<?php echo e(config('constants.developer.url')); ?>" target="_blank"><?php echo e(config('constants.developer.name')); ?></a>
							</div>
						</div>
					</div>
				</footer>
				<!-- end Footer -->
				
			</div>
		</div>
		<!-- END wrapper -->
		
		
		
		<!-- Vendor js -->
		<script src="<?php echo e(asset("assets/js/vendor.min.js")); ?>"></script>
		<!-- select2 js -->
		<script src="<?php echo e(asset("assets/libs/select2/select2.full.min.js")); ?>"></script>
		
		<!-- KNOB JS -->
		<script src="<?php echo e(asset("assets/libs/jquery-knob/jquery.knob.min.js")); ?>"></script>
		<!-- Chart JS -->
		<script src="<?php echo e(asset("assets/libs/chart-js/Chart.bundle.min.js")); ?>"></script>
		
		
		
		
		
		
		
		
		<!-- Init js-->
		<script src="<?php echo e(asset("assets/js/pages/form-advanced.init.js")); ?>"></script>
		
		<?php echo $__env->yieldContent("script"); ?>
		
		<!-- App js -->
		<script src="<?php echo e(asset("assets/js/app.min.js")); ?>"></script>
		
	</body>
	
</html><?php /**PATH D:\akbar\laravel\blog\resources\views/layouts/app.blade.php ENDPATH**/ ?>