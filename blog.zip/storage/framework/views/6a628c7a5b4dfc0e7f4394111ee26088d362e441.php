
<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection("script"); ?>
        <!-- Jvector map -->
<script src="<?php echo e(asset("assets/libs/jqvmap/jquery.vmap.min.js")); ?>"></script>
<script src="<?php echo e(asset("assets/libs/jqvmap/jquery.vmap.usa.js")); ?>"></script>


<script src="<?php echo e(asset('assets/libs/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<!-- Dashboard Init JS -->
<script src="<?php echo e(asset("assets/js/pages/dashboard.init.js")); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="content">

        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <h4 class="page-title">Dashboard</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-xl-6">
                    <div class="card-box widget-chart-one gradient-success bx-shadow-lg">
                        <div class="float-left" dir="ltr">
                            <input data-plugin="knob" data-width="80" data-height="80" data-linecap=round
                                   data-fgColor="#ffffff" data-bgcolor="rgba(255,255,255,0.2)" value="49" data-skin="tron" data-angleOffset="180"
                                   data-readOnly=true data-thickness=".1"/>
                        </div>
                        <div class="widget-chart-one-content text-right">
                            <p class="text-white mb-0 mt-2">Projects</p>
                            <h3 class="text-white">1200</h3>
                        </div>
                    </div> <!-- end card-box-->
                    <div class="card-box">
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        <h4 class="header-title">Daily Statistics</h4>
                        <p class="text-muted"><?php echo e(date("D, d F - Y")); ?></p>
                        <div class="mb-3 mt-4">
                            
                            
                            
                            
                            
                            <h2 class="font-weight-light">600/1200</h2>
                        </div>
                        <div class="chartjs-chart dash-sales-chart">
                            <canvas id="sales-chart"></canvas>
                        </div>
                    </div><!-- end card-box-->



                </div> <!-- end col -->

                <div class="col-xl-6">
                    <div class="card-box">
                        
                            
                                
                            
                            
                                
                                
                                
                                
                                
                                
                                
                                
                            
                        
                        <h4 class="header-title mb-3">Statistics</h4>
                        <div class="row text-center">
                            <div class="col-sm-4 mb-3">
                                <h3 class="font-weight-light"><?php echo e($total_news); ?></h3>
                                <p class="text-muted text-overflow">Total Post</p>
                            </div>
                            <div class="col-sm-4 mb-3">
                                <h3 class="font-weight-light"><?php echo e($total_comments); ?></h3>
                                <p class="text-muted text-overflow">Total Comments</p>
                            </div>
                            <div class="col-sm-4 mb-3">
                                <h3 class="font-weight-light"><?php echo e($total_cat); ?></h3>
                                <p class="text-muted text-overflow">Total Category</p>
                            </div>
                        </div>
                        <div class="chartjs-chart high-performing-product">
                            <canvas id="high-performing-product"></canvas>
                        </div>
                    </div> <!-- end card-box-->
                </div> <!-- end col -->


            </div>
            <!-- end row -->


        </div> <!-- container -->

    </div> <!-- content -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\akbar\laravel\blog\resources\views/app/home.blade.php ENDPATH**/ ?>