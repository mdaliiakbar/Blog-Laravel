
<?php $__env->startSection('title','Category'); ?>
<?php $__env->startSection("style"); ?>
<link href="<?php echo e(asset('assets/libs/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/libs/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection("script"); ?>
<script src="<?php echo e(asset('assets/libs/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script>
	var table;
	$(document).ready(function(){
		studentList();


	});

	function confirm_delete(){
		if(confirm("Are you sure to delete this?")){
			return true;
		} return false;
	}

	function studentList(){
		var filterData  = {
			filter_status   : $("#filter_status").val(),
			filter_type   	: $("#filter_type").val()
		};

		table = $('#studentList').DataTable
		({
			"bAutoWidth": false,
			"destroy": true,
			"bProcessing": true,
			"serverSide": true,
			"responsive": false,
			"aaSorting": [[0, 'desc']],
			"scrollX": true,
			"scrollCollapse": true,
			"columnDefs": [
				{
					"targets": [2,3,4],
					"orderable": false
				}, {
					"targets": [0,2, 3,4],
					className: "text-center"
				}],
			"ajax": {
				url: "<?php echo e(route('category_list')); ?>",
				type: "post",
				"data": {
					_token: "<?php echo e(csrf_token()); ?>",
					search: filterData
				},
				"aoColumnDefs": [{
					'bSortable': false
				}],

				"dataSrc": function (jsonData) {
					return jsonData.data;
				},
				error: function (request, status, error) {
					console.log(request.responseText);
					//toastr.warning('Server Error. Try aging!', 'Warning');
				}
			}
		});
	}
</script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


	<div class="content">

		<!-- Start Content-->
		<div class="container-fluid">

			<!-- start page title -->
			<div class="row">
				<div class="col-12">
					<div class="page-title-box">
						<div class="page-title-right">
							<ol class="breadcrumb m-0">
								<li class="breadcrumb-item"><a href="javascript: void(0);">Category</a></li>
								<li class="breadcrumb-item active">Category List</li>
							</ol>
						</div>
						<h4 class="page-title"><?php echo $__env->yieldContent("title"); ?></h4>
					</div>
				</div>
			</div>
			<!-- end page title -->

			<div class="row">
				<div class="col-12">
					<?php if(session()->has('msg')): ?>
					<div class="card-box">
						<div class="alert alert-success">
							<?php echo e(session()->get('msg')); ?>

						</div>
					</div> <!-- end card-box -->
					<?php endif; ?>
					<div class="card-box">
						<table id="studentList" class="table table-bordered dt-responsive nowrap">
							<thead>
							<tr>
								<th>#</th>
								<th>Title</th>
								<th>Post</th>
								<th>Status</th>
								<th class="text-center">Action</th>
							</tr>
							</thead>
							<tbody></tbody>
						</table>
					</div> <!-- end card-box -->
				</div> <!-- end col -->
			</div> <!-- end row -->


		</div> <!-- container-fluid -->

	</div> <!-- content -->


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\akbar\laravel\blog\resources\views/app/category/index.blade.php ENDPATH**/ ?>