<?php


return [

    'developer' => [
        'name' => 'Blog',
        'url'=>'/'
    ],
    'development'=> [
        'session'=> date("Y")
    ],
    'software' => [
        'name' => 'Blog'
    ],
    

    'sms_bundle'=>[
        'token'=>''
    ]
];